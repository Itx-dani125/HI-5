import { useState } from 'react';
import CapabilitiesSecondSection from './CapabilitiesSecondSection';
import TakeCare from './TakeCare';

const CapabilitiesSection = () => {
  
  return (
    <>
      <div className="relative min-h-screen w-full overflow-hidden">
        {/* Background Image */}
        <div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: 'url("./cap-banner.png")',
          }}
        >
          {/* Dark overlay for better text readability */}
          <div className="absolute inset-0 bg-black bg-opacity-60"></div>
        </div>

        {/* Hero Content */}
        <div className="relative z-10 flex items-center min-h-screen">
          <div className="container mx-auto px-6 lg:px-8">
            <div className="max-w-4xl">
              {/* Main Headline */}
              <h1 className="text-5xl ml-[10%] sm:text-6xl lg:text-7xl xl:text-8xl font-bold text-white leading-tight mb-6">
                <span className="block font-serif">Capabilities</span>
                <span className="block font-serif">Lorem</span>
                <span className="block font-serif">Lorem Ipsum</span>
              </h1>

              {/* Subtitle */}
              <p className="text-lg sm:text-xl ml-[10%] lg:text-2xl text-white text-opacity-90 mb-8 max-w-2xl leading-relaxed">
                Click edit button to change this text. Lorem ipsum dolor sit
                amet, consectetur adipiscing elit.
              </p>

              {/* CTA Button */}
              <button className="group inline-flex ml-[10%] items-center space-x-3 bg-primary hover:bg-secondary hover:text-primary text-white px-8 py-4 text-lg font-semibold rounded-none transition-all duration-300 hover:shadow-2xl hover:shadow-teal-500/25 transform hover:-translate-y-1">
                <span>Lorem Ipsum</span>
                <svg
                  className="w-5 h-5 group-hover:translate-x-1 transition-transform duration-300"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M17 8l4 4m0 0l-4 4m4-4H3"
                  />
                </svg>
              </button>
            </div>
          </div>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-10">
          <div className="animate-bounce">
            <svg
              className="w-6 h-6 text-white text-opacity-70"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M19 14l-7 7m0 0l-7-7m7 7V3"
              />
            </svg>
          </div>
        </div>
      </div>

      <CapabilitiesSecondSection />
      {/* second section */}
      <div className="w-full min-h-[50vh] flex flex-col justify-center items-center px-4 sm:px-6 md:px-8 py-10 gap-6">
        <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl text-primary font-medium text-center mb-4">
          Partner for Federal Opportunities
        </h1>

        <div className="w-1/2 sm:w-1/3 md:w-[30%] h-1 bg-primary" />

        <p className="text-sm sm:text-base md:text-lg text-center w-full sm:w-[90%] md:w-[80%] lg:w-[70%]">
          We can provide you with qualified candidates that can be potential
          permanent hires that will stick with you while you connect with
          different federal opportunities that you might be interested in. It is
          our intent to make sure to give you the peace of mind when hiring an
          individual while working on securing a permanent contract with
          different agencies. Our candidates have also been placed in the US
          Federal Agencies such as, the Department of Defense, Air Force, US
          Navy, NASA, NGA, DHS, CBP, UST and FBI.
        </p>
      </div>

      <TakeCare />
    </>
  )
};

export default CapabilitiesSection;