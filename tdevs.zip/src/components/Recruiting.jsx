import React from 'react'


const positions = [
  { icon: './message.svg', title: 'Cybersecurity' },
  { icon: './message.svg', title: 'Aerospace' },
  { icon: './message.svg', title: 'Systems Engineering  ' },
  { icon: './message.svg', title: 'Network Design & Architecture' },
  { icon: './message.svg', title: 'Program & Project Management' },
  { icon: './message.svg', title: 'Information Systems Security ' },
  { icon: './message.svg', title: 'Software Engineer' },
  { icon: './message.svg', title: 'SharePoint Developer' },
  { icon: './message.svg', title: 'PeopleSoft Developer' },
  { icon: './message.svg', title: 'Database Administrator' },
  { icon: './message.svg', title: 'BigData Architect' },
  { icon: './message.svg', title: 'IT Specialist' },
];

const Recruiting = () => {
  return (
    <div>
      <section className="relative h-[80vh] flex flex-col items-center justify-center bg-gradient-to-r from-slate-800 to-slate-900 text-white py-20">
        <div
          className="absolute inset-0 bg-cover bg-center opacity-20"
          style={{
            backgroundImage: 'url("./industires-banner.png")',
          }}
        />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">Industries</h1>
          <p className="text-xl md:text-2xl text-slate-300 mb-8 max-w-3xl mx-auto">
            Our experience with different realms of industries has gained us a
            unique expertise that makes our clients trust us and our process
            without hesitancy.
          </p>
        </div>
      </section>

      <div className="w-full py-16 px-4 lg:px-20 text-center">
        <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-primary mb-4">
          Positions we are <br className="sm:hidden" /> Recruiting for
        </h2>
        <div className="w-20 h-1 bg-primary mx-auto my-4 rounded-full" />

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8 mt-10">
          {positions.map((pos, index) => (
            <div
              key={index}
              className="flex items-center gap-4 text-left"
            >
              <div className="w-14 h-14 flex items-center justify-center rounded-full border">
                <img
                  src={pos.icon}
                  alt={pos.title}
                  className="w-8 h-8 object-contain"
                />
              </div>
              <p className="font-semibold text-lg">{pos.title}</p>
            </div>
          ))}
        </div>
      </div>

      <section className="w-full bg-gray-50 py-16 px-6 md:px-12">
        <div className="max-w-7xl mx-auto flex flex-col-reverse lg:flex-row items-center gap-10">
          {/* Text Section */}
          <div className="w-full lg:w-1/2">
            <p className="text-sm font-semibold text-primary border-l-4 border-primary pl-3 mb-2">
              Know Who We Are
            </p>
            <h2 className="text-3xl md:text-4xl font-extrabold text-gray-900 mb-6">
              About our company
            </h2>
            <p className="text-gray-700 leading-relaxed mb-6">
              We are a Recruiting and Web Development company. Our founders have
              extensive experience in industries like Recruiting and Staffing,
              Web Design and Development, Graphic Designing, Sales and
              Marketing. We work with a problem-solving mindset for our
              customers and have a goal to deliver good quality work at a fair
              price. We’re customer focused, customer obsessed and work as your
              partner to achieve a common goal.
            </p>

            <div className="flex items-start gap-2">
              <img
                src="./quote.jpg"
                alt="quote"
                className="w-6 h-6 mt-1"
              />
              <p className="italic text-gray-700">
                Its an approach that we provide the best Recruitment on hard to
                fill positions and the best Web Development to Our Customers.
                <br />
                <span className="text-primary font-semibold mt-2 block">
                  – CEO @ Hi5-Consulting
                </span>
              </p>
            </div>
          </div>

          {/* Image Section */}
          <div className="w-full lg:w-1/2">
            <img
              src="./hand-shake.jpg" // Replace with your actual path
              alt="Handshake"
              className="w-full rounded-lg shadow-md object-cover"
            />
          </div>
        </div>
      </section>
    </div>
  )
}

export default Recruiting