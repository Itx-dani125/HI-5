import React, { useState } from 'react';

// Base Section Component
const BaseSection = ({ 
  title, 
  description, 
  imageUrl, 
  imageAlt, 
  reversed = false,
  accentColor = "primary",
  backgroundColor = "white",
  children
}) => {
  const [imageLoaded, setImageLoaded] = useState(false);

  const getAccentColorClasses = () => {
    switch (accentColor) {
      case 'secondary':
        return {
          border: 'border-secondary-200',
          text: 'text-secondary-600',
          bg: 'bg-secondary-50'
        };
      case 'accent':
        return {
          border: 'border-accent-200',
          text: 'text-accent-600',
          bg: 'bg-accent-50'
        };
      default:
        return {
          border: 'border-primary-200',
          text: 'text-primary-600',
          bg: 'bg-primary-50'
        };
    }
  };

  const colors = getAccentColorClasses();
  const bgClass = backgroundColor === 'gray' ? 'bg-gray-50' : 'bg-white';

  return (
    <section className={`py-16 lg:py-24 ${bgClass}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className={`flex flex-col ${reversed ? 'lg:flex-row-reverse' : 'lg:flex-row'} items-center gap-12 lg:gap-16`}>
          {/* Text Content */}
          <div className="flex-1 space-y-6">
            <div className='w-16 h-1 bg-primary'></div>
            <div className={`w-16 h-1 ${colors.bg} rounded-full`}></div>
            <h2 className="text-3xl w-[70%] lg:text-4xl  text-gray-900 leading-tight">
              {title}
            </h2>
            <div className="space-y-4 text-gray-600 leading-relaxed">
              {Array.isArray(description) ? (
                description.map((paragraph, index) => (
                  <p key={index} className="text-base text-gray-400 lg:text-lg">
                    {paragraph}
                  </p>
                ))
              ) : (
                description.split('\n').map((paragraph, index) => (
                  <p key={index} className="text-base text-gray-400 lg:text-lg">
                    {paragraph}
                  </p>
                ))
              )}
            </div>
          </div>

          {/* Image or Custom Content */}
          <div className="flex-1 flex justify-center">
            {children ? (
              children
            ) : (
              <div className="relative w-full max-w-md lg:max-w-lg">
                <div className={`absolute inset-0 ${colors.bg} rounded-2xl transform rotate-3 opacity-20`}></div>
                <div className="relative">
                  {!imageLoaded && (
                    <div className="w-full h-80 bg-gray-100 rounded-2xl animate-pulse flex items-center justify-center">
                      <div className="w-16 h-16 bg-gray-200 rounded-full"></div>
                    </div>
                  )}
                  <img
                    src={imageUrl}
                    alt={imageAlt}
                    className={`w-full h-full object-cover rounded-2xl  transition-opacity duration-300 ${
                      imageLoaded ? 'opacity-100' : 'opacity-0'
                    }`}
                    onLoad={() => setImageLoaded(true)}
                  />
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

// Social Media Icons Component
const SocialMediaIcons = () => {
  const socialIcons = [
    { name: 'Twitter', color: 'bg-blue-500', size: 'w-12 h-12', position: 'top-4 left-8' },
    { name: 'Instagram', color: 'bg-pink-500', size: 'w-10 h-10', position: 'top-16 right-12' },
    { name: 'Facebook', color: 'bg-blue-600', size: 'w-8 h-8', position: 'bottom-20 left-4' },
    { name: 'LinkedIn', color: 'bg-blue-700', size: 'w-9 h-9', position: 'bottom-32 right-8' },
    { name: 'WhatsApp', color: 'bg-green-500', size: 'w-11 h-11', position: 'bottom-8 right-16' },
    { name: 'YouTube', color: 'bg-red-500', size: 'w-8 h-8', position: 'top-32 left-12' },
  ];

  const [phoneLoaded, setPhoneLoaded] = useState(false);

  return (
    <div className="relative w-full max-w-sm">
      {/* Floating Social Media Icons */}
      <div className="absolute inset-0 pointer-events-none">
        {socialIcons.map((icon, index) => (
          <div
            key={icon.name}
            className={`absolute ${icon.position} ${icon.color} ${icon.size} rounded-full shadow-lg animate-bounce`}
            style={{
              animationDelay: `${index * 0.2}s`,
              animationDuration: '3s'
            }}
          >
            <div className="w-full h-full flex items-center justify-center">
              <div className="w-4 h-4 bg-white rounded-sm opacity-80"></div>
            </div>
          </div>
        ))}
      </div>

      {/* Phone Mockup */}
      <div className="relative z-10 mx-auto">
        <div className="w-64 h-128 bg-gray-900 rounded-3xl p-2 shadow-2xl">
          <div className="w-full h-full bg-white rounded-2xl overflow-hidden relative">
            {/* Phone Screen Content */}
            <div className="absolute top-4 left-1/2 transform -translate-x-1/2 w-16 h-1 bg-gray-900 rounded-full"></div>
            
            {!phoneLoaded && (
              <div className="w-full h-full bg-gray-100 animate-pulse flex items-center justify-center">
                <div className="w-16 h-16 bg-gray-200 rounded-full"></div>
              </div>
            )}
            
            <img
              src="https://images.pexels.com/photos/147413/twitter-facebook-together-exchange-of-information-147413.jpeg?auto=compress&cs=tinysrgb&w=800"
              alt="Social Media Interface"
              className={`w-full h-full object-cover transition-opacity duration-300 ${
                phoneLoaded ? 'opacity-100' : 'opacity-0'
              }`}
              onLoad={() => setPhoneLoaded(true)}
            />
            
            {/* Phone Screen Overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-gray-900/20 to-transparent"></div>
          </div>
        </div>
      </div>
    </div>
  );
};

// Individual Section Components
const RecruitingSection = () => {
  const description = `When recruiting for your company, searching for the perfect hire can be a hassle, let us make this job easier for you as we make sure to connect you with the best talent available that matches with all of your staffing requirements. It's always our top priority to make sure you hire someone that not only produces the work required but also fits in your company just as well. While working closely with your company, it is our goal to make sure every single hire is a 100% satisfactory.`;

  return (
    <BaseSection
      title="Recruiting and Staffing Industry"
      description={description}
      imageUrl="./Recrutment.svg"
      imageAlt="Recruiting and staffing professionals in a meeting"
      accentColor="primary"
      backgroundColor="white"
    />
  );
};

const WebDevelopmentSection = () => {
  const description = `Our web development and designing team is your one stop to solving all your web related issues. Web design plays a huge part in making your company look their best whether it be through an interactive web app or a complex website. We want to provide our clients with top of the line services that would guarantee that your web layout meets your company's potential, connecting you and your users in such a way that is efficient and unique.`;

  return (
    <BaseSection
      title="Web Development & Designing"
      description={description}
      imageUrl="./development.svg"
      imageAlt="Web developer working on code"
      reversed={true}
      accentColor="secondary"
      backgroundColor="white"
    />
  );
};

const GraphicDesignSection = () => {
  const description = `It takes a second to make an impression that lasts, and with the right tools, your company might just be able to impress the right people. Whether it’s with an attractive logo or a pop of color, or anything else you have in mind; our graphic designing services will cater to all your needs. Our designers will add the little spark your company needs to catch people’s eyes. In order to make sure your company’s ideas and services are projected clearly to customers in such a way that makes them stick around, our graphic designers will work closely with you to make your vision comes to life.`;

  return (
    <BaseSection
      title="Graphic Designing"
      description={description}
      imageUrl="./graphic.svg"
      imageAlt="graphic designer working on design"
      reversed={true}
      accentColor="secondary"
      backgroundColor="white"
    />
  );
};

const SearchEngineOptimization = () => {
  const description = `Building a strong SEO foundation is the first step to making sure your company is meeting its maximum online potential. It helps you target the right audience, build a solid online presence, and manage your social media traffic. Our SEO price packages and digital marketing packages USA just might be the thing for your company to break into the online market.`;

  return (
    <BaseSection
      title="Search Engine Optimization"
      description={description}
      imageUrl="./google.svg"
      imageAlt="Search Engine Optimization"
      reversed={false}
      accentColor="secondary"
      backgroundColor="white"
    />
  );
};


const SocialMediaSection = () => {
  const description = [
    "In this new age, social media marketing is important for any company to get their brand out there and navigate their way into the market. It is a way for companies to connect to their clients and make sure potential consumers are aware of where they might be able to get the services they need. Social media has become one of the primary platforms to utilize in order to market your company.",
    "We are SMM services company put effort in identifying ways to make sure your company not only reaches the desired audiences effectively but also leaves a mark!"
  ];

  return (
    <BaseSection
      title="Social Media Marketing"
      description={description}
      accentColor="secondary"
      backgroundColor="gray"
    >
      <SocialMediaIcons />
    </BaseSection>
  );
};

// Main Services Page Component
const ServicesSection = () => {
  return (
    <div className="min-h-screen bg-white">
      {/* Main Content */}
      <main>
        <RecruitingSection />
        <WebDevelopmentSection />
        <SocialMediaSection />
        <GraphicDesignSection />
        <SearchEngineOptimization />
      </main>
    </div>
  );
};

export default ServicesSection;