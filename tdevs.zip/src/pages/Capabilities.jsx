import React from 'react'
import CapabilitiesSection from '../components/CapabilitiesSection'

const Capabilities = () => {
  return (
    <div>
      <CapabilitiesSection />
    </div>
  )
}

export default Capabilities