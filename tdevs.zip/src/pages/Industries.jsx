import React from 'react'
import Recruiting from '../components/Recruiting'

const Industries = () => {
  return (
    <div>
      <Recruiting />
    </div>
  )
}

export default Industries