import React from 'react'
import JobHomePage from './JobHomePage'

const Jobs = () => {
  return (
    <div>
      <JobHomePage />
    </div>
  )
}

export default Jobs