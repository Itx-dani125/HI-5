import React from 'react'
import ServicesBanner from '../components/ServicesBanner'

const Services = () => {
  return (
    <div>
      <ServicesBanner />
    </div>
  )
}

export default Services